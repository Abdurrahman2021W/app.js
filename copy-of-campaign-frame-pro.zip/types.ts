
export interface NavItem {
  label: string;
  href: string;
}

export interface Feature {
  title: string;
  description: string;
  icon: string;
  image?: string;
}

export interface SocialLink {
  icon: string;
  href: string;
  label: string;
}
