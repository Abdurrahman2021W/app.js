
import { NavItem, Feature, SocialLink } from './types.ts';

// Main site configuration
export const SITE_NAME = "CAMPAIGN FRAME PRO";
export const TAGLINE = "Create high-impact official campaign profile pictures.";

// Navigation items for header and footer
export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#' },
  { label: 'Generator', href: '#generator' },
  { label: 'Instructions', href: '#instructions' },
];

// Feature highlights for the campaign
export const FEATURES: Feature[] = [
  {
    title: "HD Resolution",
    description: "Export at 1080x1080, perfect for Facebook and WhatsApp.",
    icon: "fa-image",
  },
  {
    title: "Bangla Support",
    description: "Built-in support for high-quality Bengali typography.",
    icon: "fa-language",
  },
  {
    title: "Easy Customization",
    description: "Simple zoom and pan controls to fit any portrait.",
    icon: "fa-sliders-h",
  }
];

// Social media links for footer
export const SOCIAL_LINKS: SocialLink[] = [
  { icon: 'fa-facebook-f', href: '#', label: 'Facebook' },
  { icon: 'fa-twitter', href: '#', label: 'Twitter' },
  { icon: 'fa-whatsapp', href: '#', label: 'WhatsApp' },
];

export const SLOGANS = {
  BANGLA_TOP_1: "জয় বাংলা",
  BANGLA_TOP_2: "জয় বঙ্গবন্ধু",
  ENGLISH_TOP_1: "Joy Bangla",
  ENGLISH_TOP_2: "Joy Bangabandhu",
  BANGLA_HEADLINE: "নৌকা ছাড়া কিসের ভোট?",
  ENGLISH_STACKED: ["NO", "BOAT", "NO", "VOTE"],
};

export const COLORS = {
  BRAND_RED: "#f42a41",
  WHITE: "#ffffff",
  ACCENT_DARK: "rgba(0, 0, 0, 0.1)",
};

export const CANVAS_CONFIG = {
  SIZE: 1080,
  PHOTO_RADIUS_RATIO: 0.39,
  BORDER_WIDTH: 0, // Reference image doesn't have a thick white border, just the cutout
};
