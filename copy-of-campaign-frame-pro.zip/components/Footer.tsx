
import React from 'react';
import { SITE_NAME, SOCIAL_LINKS } from '../constants.ts';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2">
            <a href="#" className="text-3xl font-black mb-6 block">
              <span className="text-red-500">NO BOAT</span> NO VOTE
            </a>
            <p className="text-slate-400 max-w-sm mb-8 leading-relaxed">
              We are a non-profit initiative dedicated to fair maritime access and reasonable registration policies. Help us protect our community's rights.
            </p>
            <div className="flex space-x-5">
              {SOCIAL_LINKS.map((link, idx) => (
                <a 
                  key={idx} 
                  href={link.href} 
                  aria-label={link.label}
                  className="w-10 h-10 border border-slate-700 rounded-full flex items-center justify-center hover:bg-red-600 hover:border-red-600 transition-all"
                >
                  <i className={`fab ${link.icon}`}></i>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Explore</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#mission" className="hover:text-white transition-colors">Mission Statement</a></li>
              <li><a href="#features" className="hover:text-white transition-colors">What We Do</a></li>
              <li><a href="#community" className="hover:text-white transition-colors">Our Community</a></li>
              <li><a href="#action" className="hover:text-white transition-colors">Take Action</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Contact</h4>
            <ul className="space-y-4 text-slate-400">
              <li>info@noboatnovote.org</li>
              <li>Official Advocacy Office</li>
              <li>Dhaka, Bangladesh</li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <p>&copy; {currentYear} {SITE_NAME}. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
