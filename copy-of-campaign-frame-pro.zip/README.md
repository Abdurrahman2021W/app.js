
# Official Campaign DP Generator

একটি হাই-পারফরম্যান্স ওয়েব টুল যা দিয়ে আপনি সহজেই ক্যাম্পেইনের জন্য অফিশিয়াল প্রোফাইল ফ্রেম তৈরি করতে পারবেন।

## Features
- রিয়েল-টাইম ক্যানভাস রেন্ডারিং।
- হাই-রেজোলিউশন (১০৮০x১০৮০) PNG আউটপুট।
- মোবাইল ফ্রেন্ডলি রেসপনসিভ ডিজাইন।
- ইনস্ট্যান্ট ডাউনলোড সুবিধা।

## How to Fix "Repository Already Exists" Error

যদি আপনি GitHub-এ আপলোড করার সময় দেখেন যে রিপোজিটরি অলরেডি আছে, তবে নিচের কমান্ডগুলো অনুসরণ করুন:

1. **পিসিতে আপনার প্রজেক্ট ফোল্ডারে যান।**
2. **বিদ্যমান রিপোজিটরির সাথে কানেক্ট করুন:**
   ```bash
   git remote set-url origin https://github.com/your-username/your-repo-name.git
   ```
3. **কোড পুশ করুন:**
   ```bash
   git add .
   git commit -m "Updated campaign tool"
   git push -u origin main
   ```

## Hosting on GitHub Pages

1. রিপোজিটরি সেটিংস (Settings) এ যান।
2. বাম পাশের মেনু থেকে **Pages** সিলেক্ট করুন।
3. **Build and deployment** সেকশনে Branch হিসেবে `main` এবং ফোল্ডার হিসেবে `/ (root)` সিলেক্ট করে Save করুন।
4. কয়েক মিনিট পর আপনার সাইটটি লাইভ হয়ে যাবে।

## Customizing the Frame
অ্যাপের ডিজাইন বা স্লোগান পরিবর্তন করতে `App.tsx` ফাইলের `drawFrame` ফাংশনটি এডিট করুন।
