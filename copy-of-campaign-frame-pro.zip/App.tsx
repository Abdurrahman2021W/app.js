
import React, { useState, useRef, useEffect } from 'react';
import { SLOGANS, COLORS, CANVAS_CONFIG } from './constants.ts';

const App: React.FC = () => {
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [offsetX, setOffsetX] = useState(0);
  const [offsetY, setOffsetY] = useState(0);
  const [isReady, setIsReady] = useState(false);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const drawFrame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { SIZE, PHOTO_RADIUS_RATIO } = CANVAS_CONFIG;
    const centerX = SIZE / 2;
    const centerY = SIZE / 2;
    const radius = SIZE * PHOTO_RADIUS_RATIO;

    // 1. Background Setup
    ctx.clearRect(0, 0, SIZE, SIZE);
    ctx.fillStyle = COLORS.BRAND_RED;
    ctx.fillRect(0, 0, SIZE, SIZE);

    // Subtle Professional Texture
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    const dotSpacing = 30;
    for (let x = 0; x < SIZE; x += dotSpacing) {
      for (let y = 0; y < SIZE; y += dotSpacing) {
        ctx.beginPath();
        ctx.arc(x, y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 2. User Image Cutout
    ctx.save();
    const circleY = centerY - 120;
    ctx.beginPath();
    ctx.arc(centerX, circleY, radius + 15, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    if (image) {
      const baseScale = Math.max((radius * 2.5) / image.width, (radius * 2.5) / image.height);
      const currentScale = baseScale * zoom;
      const drawWidth = image.width * currentScale;
      const drawHeight = image.height * currentScale;
      const dx = centerX - drawWidth / 2 + offsetX;
      const dy = circleY - drawHeight / 2 + offsetY;
      ctx.drawImage(image, dx, dy, drawWidth, drawHeight);
    } else {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, SIZE, SIZE);
      ctx.fillStyle = '#f42a41';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '900 60px "Unbounded"';
      ctx.fillText('SELECT PHOTO', centerX, circleY);
    }
    ctx.restore();

    // 3. Bottom Aesthetic Curve
    ctx.fillStyle = COLORS.BRAND_RED;
    ctx.beginPath();
    ctx.moveTo(0, SIZE - 280);
    ctx.quadraticCurveTo(SIZE / 2, SIZE - 400, SIZE, SIZE - 280);
    ctx.lineTo(SIZE, SIZE);
    ctx.lineTo(0, SIZE);
    ctx.fill();

    // 4. TOP TEXTS
    ctx.fillStyle = COLORS.WHITE;
    ctx.textBaseline = 'top';
    ctx.textAlign = 'left';
    ctx.font = '700 32px "Hind Siliguri"';
    ctx.fillText("জয় বাংলা", 60, 50);
    ctx.fillText("জয় বঙ্গবন্ধু", 60, 95);

    ctx.textAlign = 'right';
    ctx.font = '700 22px "Unbounded"'; 
    ctx.fillText("JOY BANGLA", SIZE - 60, 50);
    ctx.fillText("JOY BANGABANDHU", SIZE - 60, 90);

    // 5. DECORATIVE VERTICAL LINES
    ctx.strokeStyle = COLORS.WHITE;
    ctx.lineWidth = 12;
    ctx.lineCap = 'butt';
    ctx.beginPath();
    ctx.moveTo(310, SIZE - 120);
    ctx.lineTo(310, SIZE);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(630, SIZE - 150);
    ctx.lineTo(630, SIZE);
    ctx.stroke();

    // 6. BOTTOM SLOGANS
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    const leftTextX = 310;
    ctx.font = '900 65px "Hind Siliguri"';
    ctx.fillText("নৌকা", leftTextX, SIZE - 265); 
    ctx.font = '700 28px "Hind Siliguri"';
    ctx.fillText("ছাড়া কিসের", leftTextX, SIZE - 195); 
    ctx.font = '900 110px "Hind Siliguri"'; 
    ctx.fillText("ভোট?", leftTextX, SIZE - 105);

    ctx.textAlign = 'left';
    const rightTextX = 660;
    ctx.font = '900 100px "Unbounded"';
    ctx.fillText("NO", rightTextX, SIZE - 260);
    ctx.font = '900 40px "Unbounded"';
    ctx.fillText("BOAT", rightTextX, SIZE - 200);
    ctx.font = '900 100px "Unbounded"';
    ctx.fillText("NO", rightTextX, SIZE - 140);
    ctx.font = '900 70px "Unbounded"';
    ctx.fillText("VOTE", rightTextX, SIZE - 70);

    // 7. BEAUTIFUL BOAT ICON (REFINED)
    ctx.save();
    ctx.translate(SIZE / 2, SIZE - 180);
    ctx.fillStyle = COLORS.WHITE;
    ctx.strokeStyle = COLORS.WHITE;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Boat Hull (Body)
    ctx.beginPath();
    ctx.moveTo(-130, 10); // Left tip
    ctx.quadraticCurveTo(0, 90, 130, 10); // Bottom curve
    ctx.quadraticCurveTo(0, 60, -130, 10); // Inner top curve
    ctx.fill();

    // Boat Chhai (Roof)
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(-45, 30);
    ctx.quadraticCurveTo(0, -60, 45, 30); // Top of roof
    ctx.stroke();
    
    // Roof Lines (Detail)
    ctx.lineWidth = 3;
    for (let i = -30; i <= 30; i += 15) {
      ctx.beginPath();
      ctx.moveTo(i, 20);
      ctx.quadraticCurveTo(0, -50, i, 20);
      ctx.stroke();
    }

    // Boitha (Oar) - Large diagonal stroke
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(-70, 50);
    ctx.lineTo(-150, -30);
    ctx.stroke();
    
    // Oar Blade
    ctx.beginPath();
    ctx.moveTo(-145, -25);
    ctx.lineTo(-170, -60);
    ctx.lineTo(-135, -55);
    ctx.closePath();
    ctx.fill();

    // Rudder (Hal) - At the back
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(115, 30);
    ctx.lineTo(150, 60);
    ctx.stroke();

    // Small water waves below
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.6;
    for (let j = 0; j < 3; j++) {
      ctx.beginPath();
      ctx.moveTo(-100 + (j*20), 85 + (j*10));
      ctx.quadraticCurveTo(0, 75 + (j*10), 100 - (j*20), 85 + (j*10));
      ctx.stroke();
    }
    
    ctx.restore();
  };

  useEffect(() => {
    const handleReady = async () => {
      await document.fonts.ready;
      drawFrame();
      setIsReady(true);
    };
    handleReady();
  }, [image, zoom, offsetX, offsetY]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        setImage(img);
        setZoom(1);
        setOffsetX(0);
        setOffsetY(0);
      };
      img.src = URL.createObjectURL(file);
    }
  };

  const downloadImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `official-campaign-dp-${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png', 1.0);
    link.click();
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-10 px-4 bg-[#fdfcfb]">
      <header className="w-full max-w-4xl text-center mb-10">
        <div className="flex flex-col items-center gap-3 mb-6">
          <div className="bg-black text-white inline-block px-4 py-1 font-black text-[10px] uppercase tracking-[0.3em] shadow-sm">
            Official Media Center
          </div>
          {isReady && (
            <div className="flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1 rounded-full border border-green-100">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-[8px] font-black uppercase tracking-widest">System Ready</span>
            </div>
          )}
        </div>
        <h1 className="text-4xl md:text-6xl font-black text-black tracking-tighter uppercase italic unbounded mb-3">
          CAMPAIGN <span className="text-rose-600">EDITOR</span>
        </h1>
        <p className="text-slate-500 font-bold text-[10px] uppercase tracking-[0.3em] max-w-lg mx-auto leading-relaxed">
          High-resolution DP Generator for Digital Support
        </p>
      </header>

      <main className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="canvas-wrapper neo-card !shadow-none !border-black overflow-hidden bg-white">
            <canvas ref={canvasRef} width={CANVAS_CONFIG.SIZE} height={CANVAS_CONFIG.SIZE} />
          </div>
          <div className="mt-8 flex items-center space-x-3 bg-white border-2 border-black p-3 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
            <i className="fas fa-certificate text-rose-600"></i>
            <span className="text-[9px] font-black uppercase tracking-widest text-black">Official HD Output Protocol</span>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4 w-full">
          <div className="neo-card p-5 bg-white overflow-hidden transition-all hover:border-rose-600">
            <div className="flex justify-between items-center mb-3">
              <h3 className="unbounded text-[10px] font-black uppercase tracking-widest text-rose-600">01 // SOURCE PORTRAIT</h3>
              <i className={`fas ${image ? 'fa-check-circle text-green-500' : 'fa-circle text-slate-100'}`}></i>
            </div>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-6 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50 flex items-center px-5 space-x-4 hover:border-rose-400 hover:bg-rose-50/50 transition-all group active:scale-[0.98]"
            >
              <div className="w-10 h-10 flex-shrink-0 bg-black rounded-lg text-white flex items-center justify-center group-hover:bg-rose-600 transition-all shadow-lg">
                <i className="fas fa-upload text-sm"></i>
              </div>
              <div className="text-left">
                <p className="text-[10px] font-black text-black uppercase tracking-wider">Upload Photo</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase">PNG/JPG Format</p>
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
            </button>
          </div>

          <div className={`neo-card p-5 transition-all ${!image ? 'bg-slate-50 opacity-90' : 'bg-white'}`}>
            <h3 className="unbounded text-[10px] font-black uppercase tracking-widest text-rose-600 mb-4">02 // POSITIONING</h3>
            {image ? (
              <div className="space-y-6 animate-in fade-in duration-500">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">Zoom</span>
                    <span className="unbounded text-[8px] font-black bg-black text-white px-2 py-0.5">{(zoom * 100).toFixed(0)}%</span>
                  </div>
                  <input type="range" min="0.5" max="3" step="0.01" value={zoom} onChange={(e) => setZoom(parseFloat(e.target.value))} className="w-full" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 block mb-1.5">Move X</span>
                    <input type="range" min="-600" max="600" step="1" value={offsetX} onChange={(e) => setOffsetX(parseInt(e.target.value))} className="w-full" />
                  </div>
                  <div>
                    <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 block mb-1.5">Move Y</span>
                    <input type="range" min="-600" max="600" step="1" value={offsetY} onChange={(e) => setOffsetY(parseInt(e.target.value))} className="w-full" />
                  </div>
                </div>
                <button onClick={() => { setZoom(1); setOffsetX(0); setOffsetY(0); }} className="w-full py-2 bg-slate-100 text-black text-[8px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all">
                  <i className="fas fa-redo mr-1.5"></i> Reset Positioning
                </button>
              </div>
            ) : (
              <div className="py-8 flex flex-col items-center justify-center text-slate-300 border-2 border-slate-100 rounded-lg">
                <i className="fas fa-image text-xl mb-2 opacity-10"></i>
                <p className="text-[8px] font-black uppercase tracking-[0.2em] text-center px-4">Upload image to enable controls</p>
              </div>
            )}
          </div>

          <div className="neo-card p-5 bg-white">
            <h3 className="unbounded text-[10px] font-black uppercase tracking-widest text-rose-600 mb-4">03 // DOWNLOAD FRAME</h3>
            <button 
              disabled={!image}
              onClick={downloadImage}
              className={`w-full py-4 text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center space-x-3 transition-all neo-button ${image ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-300 cursor-not-allowed border-slate-200'}`}
            >
              <i className="fas fa-file-download"></i>
              <span>Save Official DP</span>
            </button>
            <p className="mt-3 text-[7px] text-center text-slate-400 font-bold uppercase tracking-widest">
              HD 1080x1080 PNG Format
            </p>
          </div>
        </div>
      </main>

      <footer className="mt-20 w-full max-w-6xl border-t-2 border-black pt-10 pb-16">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-10">
          <div className="space-y-3">
            <h4 className="unbounded text-xl font-black uppercase mb-1">NO BOAT <span className="text-rose-600">NO VOTE</span></h4>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Digital Campaign Toolkit v3.5 // Official Edition</p>
            <div className="pt-2">
               <a 
                href="https://www.facebook.com/awamileague.1949korso" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-3 bg-[#1877F2] text-white px-5 py-3 text-[10px] font-black uppercase tracking-[0.2em] shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[-2px] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all"
               >
                 <i className="fab fa-facebook text-sm"></i>
                 <span>Official Facebook Page</span>
               </a>
            </div>
          </div>
          
          <div className="text-right flex flex-col items-start lg:items-end space-y-2">
            <p className="text-[10px] font-black text-black uppercase tracking-[0.4em]">
              &copy; {new Date().getFullYear()} Official Media Cell
            </p>
            <div className="flex space-x-4">
              <span className="text-[8px] font-black uppercase text-slate-400">Verified Tool</span>
              <span className="text-[8px] font-black uppercase text-slate-400">Security Standard v3</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
